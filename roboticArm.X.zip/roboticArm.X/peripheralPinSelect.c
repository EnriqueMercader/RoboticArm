#include "peripheralPinSelect.h"

void peripheralPinSelect_Configuration(void){
    RXPPS  = 0x08;   //RB0->EUSART:RX;    
    RB1PPS = 0x10;   //RB1->EUSART:TX;    
    RB7PPS = 0x0C;   //RB7->CCP4:CCP4;    
    RB2PPS = 0x0B;   //RB2->CCP3:CCP3;    
    RC4PPS = 0x09;   //RC4->CCP1:CCP1;    
    RC2PPS = 0x0A;   //RC2->CCP2:CCP2;    
}
