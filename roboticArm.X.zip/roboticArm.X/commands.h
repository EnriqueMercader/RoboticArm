#ifndef COMMANDS_H
#define	COMMANDS_H

/* Includes */
#include <xc.h>
#include "interrupt.h"
#include "uart.h"
#include "rgbLed.h"
#include "strings.h"

/* Function Prototypes */
void checkCommand(const char *inputString);

#endif	/* COMMANDS_H */

