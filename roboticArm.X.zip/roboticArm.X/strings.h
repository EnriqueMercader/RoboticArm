#ifndef STRINGS_H
#define	STRINGS_H
    /* Includes */
    #include <xc.h>
    #include <stdbool.h>
    
    /* Functions */
    bool compareString(const char *referenceString, const char *inputString);
    bool compareStringPartially(const char *referenceString, const char *inputString);

#endif	/* STRINGS_H */

