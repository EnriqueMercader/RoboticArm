#include "interrupt.h"

void __interrupt() myISR (void){
    /* Encoders */
    if(EncoderA_Flag){
        if (motor_A_right){
            actualPosition[MotorA]++;
        }
        else if (motor_A_left){
            if (actualPosition[MotorA] > 0){
                actualPosition[MotorA]--;
            }
        }
        EncoderA_Flag = 0;  
    }	
    if(EncoderB_Flag){
        if (motor_B_right){
            actualPosition[MotorB]++;
        }
        else if (motor_B_left){
            if (actualPosition[MotorB] > 0){
                actualPosition[MotorB]--;
            }
        }
        EncoderB_Flag = 0; 
    }	
    if(EncoderC_Flag){
        if (motor_C_right){
            actualPosition[MotorC]++;
        }
        else if (motor_C_left){
            if (actualPosition[MotorC] > 0){
                actualPosition[MotorC]--;
            }
        }
        EncoderC_Flag = 0; 
    }	
    
    /* Buttons */
    if(stopButton){
        mode = stop;
        doneMessageSent = false;
        stopButton = 0;
    }
    
    /* Switches */
    if (SwtichA_Flag){
        actualPosition[MotorA] = 0;
         motor_A_left = 0;
         SwtichA_Flag = 0;
    }
    if (SwtichB_Flag){
        actualPosition[MotorB] = 0;
        motor_B_left = 0;
        SwtichB_Flag = 0;
    }
    if (SwtichC_Flag){
        actualPosition[MotorC] = 0;
        motor_C_left = 0;
        SwtichC_Flag = 0;
    }
    
    /* UART */
    if ((TransmitterAvailable) && (TransmitterEnabled)){    //If the USART transmitter is available & the transmit interrupt is enabled.
        if (transmitterString[txCurrentChar] != '\0'){      //If there are chars left to transmit.
            TXREG = transmitterString[txCurrentChar];       //Transmits a single char.
            txCurrentChar++;                                //Shifts the array position for the next character.
        }
        else{
            txCurrentChar = 0;
            TransmitterEnabled = 0;                         //Disables Transmit Interrupt.
        }
    }
    if ((NewCharacterReceived) && (ReceiverEnabled)){       //If a new character was received & the receive interrupt is enabled.
        if ((RCREG != '\r') && (RCREG != '\n')){            //If a char different than an End Of Line character is received.
            receiverString[rxCurrentChar] = RCREG;          //Copies the received character to an array position.
            rxCurrentChar++;                                //Shifts the array position for the next character.
        }
        else if (rxCurrentChar != 0){                       //If an End Of Line character is received.
            receiverString[rxCurrentChar] = '\0';           //Writes a NULL character at the last character position of the string.
            rxCurrentChar = 0;                              //Resets the character position for the next string.
            newStringReceived = true;
        }
    }
}