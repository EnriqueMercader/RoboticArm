#include "uart.h"

void uart_start(void){
    BAUD1CON = 0x08;    // ABDOVF no_overflow; SCKP Non-Inverted; BRG16 16bit_generator; WUE disabled; ABDEN disabled; 
    RC1STA = 0x90;      // SPEN enabled; RX9 8-bit; CREN enabled; ADDEN disabled; SREN disabled; 
    TX1STA = 0x24;      // TX9 8-bit; TX9D 0; SENDB sync_break_complete; TXEN enabled; SYNC asynchronous; BRGH hi_speed; CSRC slave; 
    SP1BRGL = 0x67;     // SP1BRGL 103; 
    SP1BRGH = 0x00;     // SP1BRGH 0;   
}
void uart_printString(char *inputString, bool endOfLineCharacters){
    char i;
    for (i = 0; inputString[i] != '\0'; i++) {     // Copy the characters of the string literal to the array one by one.
        transmitterString[i] = inputString[i];    //
    }
    if (endOfLineCharacters){                         //If End Of Line characters are enabled.
        transmitterString[i] = '\r';       //Appends the carriage return character.
        transmitterString[i + 1] = '\n';   //Appends the line feed character.
        i = (i + 2);                        //Shifts the array position for the null terminator.
    }
    transmitterString[i] = '\0';           //Appends the null terminator at the end.
    TXIE = 1;                               //Enables Transmit Interrupt.
}
void uart_printNumber(int inputNumber, bool endOfLine){
    //Variables
    char i = 0;
    char temp;
    char j;
    char k;

    //Code
    /*Number Splitting and storing into a string as ASCII characters.*/
    while (inputNumber != 0) {                               //Divides a number into its characters.
        transmitterString[i] = (inputNumber % 10) + '0';    //Stores each character in a string.
        inputNumber /= 10;
        i++;                                            //Shifts the string position for the next character.
    }
    if (i == 0) {                                       //If the number is a 0.
        transmitterString[i] = '0';                    //Writes the ASCII number 0 to the string.
        i++;                                            //Shifts the string position for the null terminator.
    }

    /*Array characters position reversing*/
    for (j = 0, k = i-1; j < k; j++, k--) {             //Reverses the string's characters. EG. [A][B][C]
        temp = transmitterString[j];                   //       temp = A
        transmitterString[j] = transmitterString[k];  //  --->[C][B][C]
        transmitterString[k] = temp;                   //      [C][B][A]<---
    }

    /*End Of Line characters*/
    if (endOfLine){                                     //If End Of Line characters are enabled
        transmitterString[i] = '\r';                   //Appends the carriage return character.
        transmitterString[i + 1] = '\n';               //Appends the line feed character.
        i = (i + 2);                                    //Shifts the array position for the null terminator.
    }
    transmitterString[i] = '\0';                       //Appends the null terminator at the end.
    TXIE = 1;                                           //Enables Transmit Interrupt.
}
