#ifndef INTERRUPT_H
#define	INTERRUPT_H
    /* Includes */
    #include <xc.h>
    #include "uart.h"

    /* Definitions */

        #define MotorA      0
        #define MotorB      1
        #define MotorC      2
        #define running     1
        #define goingHome   2
        #define stop        3
    
        /* Interrupt Flags*/
        #define EncoderA_Flag           IOCAF7
        #define EncoderB_Flag           IOCAF6
        #define EncoderC_Flag           IOCCF0
        #define SwtichA_Flag            IOCAF3
        #define SwtichB_Flag            IOCAF4
        #define SwtichC_Flag            IOCAF5
        #define stopButton              IOCCF5
        #define TransmitterAvailable    TXIF
        #define TransmitterEnabled      TXIE
        #define NewCharacterReceived    RCIF
        #define ReceiverEnabled         RCIE

        /* PORTS */
        #define  motor_A_left   LATB6
        #define  motor_A_right  LATB5
        #define  motor_B_left   LATB4
        #define  motor_B_right  LATB3
        #define  motor_C_left   LATD0
        #define  motor_C_right  LATD3
        #define  switchA        PORTAbits.RA3
        #define  switchB        PORTAbits.RA4
        #define  switchC        PORTAbits.RA5

        /* Servo */
        #define Servo           CCPR2L
        #define GripperOpen     74
        #define GripperClosed   18
        #define GripperOff      0

        /* PWM */
        #define MotorA_DutyCycle  CCPR4L
        #define MotorB_DutyCycle  CCPR3L
        #define MotorC_DutyCycle  CCPR1L
    
/* Global variables */
    unsigned long long desiredPosition[3] = {0,0,0};
    unsigned long long actualPosition[3] = {0,0,0};
    bool inPosition[3] = {false,true,true};
    char mode = 0;
    bool doneMessageSent = true;

#endif	/* INTERRUPT_H */

