#ifndef UART_H
#define	UART_H
    /* Includes */
    #include <xc.h>
    #include <stdbool.h>

    /*Definitions*/
    #define MaxStringLength 30                  //Maximum number of characters that can be received or send at a once.
    #define EOL             1                   //Enables End Of Line characters
    #define No_EOL          0                   //Disables End Of Line characters

    /* Global Variables */
    char transmitterString[MaxStringLength];    //Maximum length of a transmission package.
    char receiverString[MaxStringLength];       //Maximum length of a received package.
    char txCurrentChar = 0;                     //Number of the actual character of the string being transmitted.
    char rxCurrentChar = 0;                     //Number of the actual character of the string being received.
    bool newStringReceived = false;
    
    /* Function prototypes*/
    void uart_start(void);
    void uart_printString(char *inputString, bool endOfLineCharacters);
    void uart_printNumber(int inputNumber, bool endOfLine);
#endif	/* UART_H */

