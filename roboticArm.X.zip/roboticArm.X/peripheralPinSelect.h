#ifndef PERIPHERALPINSELECT_H
#define	PERIPHERALPINSELECT_H
    /* Includes */
    #include <xc.h>

    /* Function prototypes */
    void peripheralPinSelect_Configuration(void);

#endif	/* PERIPHERALPINSELECT_H */

