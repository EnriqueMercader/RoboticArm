#ifndef GENERALINPUTOUTPUT_H
#define	GENERALINPUTOUTPUT_H
    /* Includes */
    #include <xc.h>

    /* Function prototypes */
    void generalInputOutput_Configuration(void);

#endif	/* GENERALINPUTOUTPUT_H */

