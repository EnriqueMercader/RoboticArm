#ifndef TIMER_H
#define	TIMER_H
    /* Includes */
    #include <xc.h>

    /* Functions' prototypes */
    

#endif	/* TIMER_H */

