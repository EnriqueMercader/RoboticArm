#include "interrupts.h"

void interrupts_Configuration(void){
    /* Interrupt on change*/
        /*Switch A*/
        IOCAFbits.IOCAF3 = 0;   //interrupt on change for A3 - flag
        IOCANbits.IOCAN3 = 0;   //interrupt on change for A3 - negative
        IOCAPbits.IOCAP3 = 1;   //interrupt on change for A3 - positive
        
        /*Switch B*/
        IOCAFbits.IOCAF4 = 0;   //interrupt on change for A4 - flag
        IOCANbits.IOCAN4 = 0;   //interrupt on change for A4 - negative
        IOCAPbits.IOCAP4 = 1;   //interrupt on change for A4 - positive
        
        /*Switch C*/
        IOCAFbits.IOCAF5 = 0;   //interrupt on change for A5 - flag
        IOCANbits.IOCAN5 = 0;   //interrupt on change for A5 - negative
        IOCAPbits.IOCAP5 = 1;   //interrupt on change for A5 - positive
        
        /*Encoder A*/
        IOCAFbits.IOCAF7 = 0;   //interrupt on change for A7 - flag
        IOCANbits.IOCAN7 = 0;   //interrupt on change for A7 - negative
        IOCAPbits.IOCAP7 = 1;   //interrupt on change for A7 - positive
        
        /*Encoder B*/
        IOCAFbits.IOCAF6 = 0;   //interrupt on change for A6 - flag
        IOCANbits.IOCAN6 = 0;   //interrupt on change for A6 - negative
        IOCAPbits.IOCAP6 = 1;   //interrupt on change for A6 - positive
        
        /*Encoder C*/
        IOCCFbits.IOCCF0 = 0;   //interrupt on change for C0 - flag
        IOCCNbits.IOCCN0 = 0;   //interrupt on change for C0 - negative
        IOCCPbits.IOCCP0 = 1;   //interrupt on change for C0 - positive
        
        
        /*Stop Button*/
        IOCCFbits.IOCCF5 = 0;   //interrupt on change for C5 - flag
        IOCCNbits.IOCCN5 = 0;   //interrupt on change for C5 - negative
        IOCCPbits.IOCCP5 = 1;   //interrupt on change for C5 - positive
    
    PIE0bits.IOCIE = 1;     // Enable IOCI interrupt 

    /* UART */
    PIE3bits.RCIE = 0;          // receiver interrupt flag
    PIE3bits.TXIE = 0;          // transmitter interrupt flag
    PIE3bits.RCIE = 1;          // enable receive interrupt
    
    /* General */
    INTCONbits.GIE = 1;         // Enable global interrupt
    INTCONbits.PEIE = 1;        // Peripheral interrupt enable
}