#include "commands.h"

void checkCommand(const char *inputString) {
    if ((inputString[0] >= 'A') && (inputString[0] <= 'D') && (inputString[1] >= '0') && (inputString[1] <= '9')){
        char index = 0;
        char i = 0;
        while (inputString[i] != '\0') {
            if (inputString[i] >= 'A' && inputString[i] <= 'C'){
                index = (inputString[i] - 'A');
                i++;
                desiredPosition[index] = 0;                                       // Initialize the target variable
                while ((inputString[i] != '\0') && (inputString[i] != ' ')) {
                    if ((inputString[i] >= '0') && (inputString[i] <= '9')) {
                        desiredPosition[index] = ((desiredPosition[index] * 10) + (inputString[i] - '0'));
                    } else {
                        break; // Exit the loop if a non-digit character is encountered
                    }
                    i++;
                }
            }
            else {
                i++; // Move to the next character if no match is found
            }
        }
        uart_printString("ok",EOL);
        while(TXIE);
        doneMessageSent = false;
        led_setColor(purple);
        mode = running;
    }
    else if (compareStringPartially("actual",inputString)) {
        if (inputString[6] == '\0'){
            uart_printString("A",No_EOL);
            while(TXIE);
            uart_printNumber(actualPosition[(MotorA)],EOL);
            while(TXIE);
            uart_printString("B",No_EOL);
            while(TXIE);
            uart_printNumber(actualPosition[(MotorB)],EOL);
            while(TXIE);
            uart_printString("C",No_EOL);
            while(TXIE);
            uart_printNumber(actualPosition[(MotorC)],EOL);
            while(TXIE);
        }
        else if ((inputString[7] >= 'A') && (inputString[7] <= 'D')){
            uart_printNumber(actualPosition[(inputString[7] - 'A')],EOL);
        }
    }
    else if (compareStringPartially("desired",inputString)){
        if (inputString[7] == '\0'){
            uart_printString("A",No_EOL);
            while(TXIE);
            uart_printNumber(desiredPosition[(MotorA)],EOL);
            while(TXIE);
            uart_printString("B",No_EOL);
            while(TXIE);
            uart_printNumber(desiredPosition[(MotorB)],EOL);
            while(TXIE);
            uart_printString("C",No_EOL);
            while(TXIE);
            uart_printNumber(desiredPosition[(MotorC)],EOL);
            while(TXIE);
        }
        else if ((inputString[8] >= 'A') && (inputString[8] <= 'D')){
            uart_printNumber(desiredPosition[(inputString[8] - 'A')],EOL);
        }
    }
    else if (compareStringPartially("home",inputString)) {
        uart_printString("ok",EOL);
        mode = goingHome;
        led_setColor(blue);
        while(TXIE);
        doneMessageSent = false;
    }
    else if (compareStringPartially("open",inputString)) {
        Servo = GripperOpen;
        uart_printString("ok",EOL);
        while(TXIE);
        doneMessageSent = false;
    }
    else if (compareStringPartially("close",inputString)) {
        Servo = GripperClosed;
        uart_printString("ok",EOL);
        while(TXIE);
        doneMessageSent = false;
    }
    else if (compareStringPartially("hi",inputString)) {
        uart_printString("Hello there!",EOL);
        while(TXIE);
    }
    else {
        uart_printString("Invalid command",EOL);
        while(TXIE);
    }
}