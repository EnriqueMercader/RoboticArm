#ifndef CLOSEDLOOPCONTROLLER_H
#define	CLOSEDLOOPCONTROLLER_H

    /* Includes */
    #include <xc.h>
    #include "interrupt.h"

    /* Definitions */
        /* Motor Speeds */
        #define MotorA_SlowSpeed     100
        #define MotorA_HighSpeed     100
        #define MotorB_SlowSpeed     90
        #define MotorB_HighSpeed     100
        #define MotorC_SlowSpeed     60
        #define MotorC_HighSpeed     60

        #define MotorC_SpeedBoundary 40
        #define PID_Offset           1

    /* Function Prototypes */
    void closedLoopControl(void);

#endif	/* CLOSEDLOOPCONTROLLER_H */

