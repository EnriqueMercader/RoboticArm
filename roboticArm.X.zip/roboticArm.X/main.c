/* Included libraries */
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <xc.h>


/* Included files */
#include "peripheralModuleDisable.h"
#include "closedLoopController.h"
#include "peripheralPinSelect.h"
#include "generalInputOutput.h"
#include "configurationBits.h"
#include "interrupts.h"
#include "oscillator.h"
#include "interrupt.h"
#include "commands.h"
#include "strings.h"
#include "rgbLed.h"
#include "timer.h"
#include "uart.h"
#include "pwm.h"

/* Definitions */
#define _XTAL_FREQ 4000000

/* Functions' prototypes */
void device_Initialize(void);

void main(void) {
    device_Initialize();
    led_setColor(white);
    __delay_ms(500);
    led_setColor(lightGreen);
    while (1){
        if (newStringReceived){
            checkCommand(receiverString);
            newStringReceived = false;
        } 
        switch (mode) {    
            case running:
                closedLoopControl();
                if (doneMessageSent == false){
                    if ((inPosition[MotorA] == true) && (inPosition[MotorB] == true) && (inPosition[MotorC] == true)){
                        led_setColor(lightGreen);
                        uart_printString("done",EOL);
                        doneMessageSent = true;
                    }
                }
                break;
            case goingHome:
                if (switchA == 0){
                    motor_A_right = 0;
                    motor_A_left = 1;
                    MotorA_DutyCycle = MotorA_SlowSpeed;
                }
                if (switchB == 0){
                    motor_B_right = 0;
                    motor_B_left = 1;
                    MotorB_DutyCycle = MotorB_SlowSpeed;
                }
                if (switchC == 0){
                    motor_C_right = 0;
                    motor_C_left = 1;
                    MotorC_DutyCycle = MotorC_SlowSpeed;
                }
                if (switchA && switchB && switchC){
                    inPosition[MotorA] = true;
                    inPosition[MotorB] = true;
                    inPosition[MotorC] = true;
                    desiredPosition[0] = 0;
                    desiredPosition[1] = 0;
                    desiredPosition[2] = 0;
                    mode = running;
                }
                break;
            case stop:
                led_setColor(red);
                motor_A_left = 0;
                motor_A_right = 0;
                motor_B_left = 0;
                motor_B_right = 0;
                motor_C_left = 0;
                motor_C_right = 0;
                Servo = GripperOff;
                if (doneMessageSent == false){
                    uart_printString("stopped",EOL);
                    doneMessageSent = true;
                }
                break;
            default:

                break;
        }
    }
}

/* Functions */
void device_Initialize(void){
    peripheralModuleDisable_Configuration();
    generalInputOutput_Configuration();
    peripheralPinSelect_Configuration();
    oscillator_Configuration();
    pwm_start();
    uart_start();
    interrupts_Configuration();
}


