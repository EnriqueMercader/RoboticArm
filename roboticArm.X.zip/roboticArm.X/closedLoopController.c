#include "closedLoopController.h"

void closedLoopControl(void){
    /* Local variables */
    int  deviation[3];
    int  absoluteDeviation[3];
    
    /* Code */
        /*Motor A*/
            deviation[MotorA] = desiredPosition[MotorA] - actualPosition[MotorA];
            absoluteDeviation[MotorA] = abs(deviation[MotorA]);
            /*Direction Control*/
            if (deviation[MotorA] > PID_Offset){
                motor_A_left = 0;
                motor_A_right = 1;
                inPosition[MotorA] = false;
            }
            else if (deviation[MotorA] < -PID_Offset){
                motor_A_right = 0;
                motor_A_left = 1;
                inPosition[MotorA] = false;
            }
            else{
                MotorA_DutyCycle = 0;
                inPosition[MotorA] = true;
            }
            /*Velocity Control*/
            if (absoluteDeviation[MotorA] >= 80){
                MotorA_DutyCycle = MotorA_HighSpeed;
            }
            else if (absoluteDeviation[MotorA] > PID_Offset){
                MotorA_DutyCycle = MotorA_SlowSpeed;
            }
        /* Motor B */
            deviation[MotorB] = desiredPosition[MotorB] - actualPosition[MotorB];
            absoluteDeviation[MotorB] = abs(deviation[MotorB]);
            /*Direction Control */
            if (deviation[MotorB] >= PID_Offset){
                motor_B_right = 1;
                inPosition[MotorB] = false;
            }
            else if (deviation[MotorB] <= -PID_Offset){
                motor_B_left = 1;
                inPosition[MotorB] = false;
            }
            else{
                MotorB_DutyCycle = 0;
                motor_B_right = 0;
                motor_B_left = 0;
                inPosition[MotorB] = true;
            }
            /*Velocity Control */
            if (absoluteDeviation[MotorB] >= 80){
                MotorB_DutyCycle = MotorB_HighSpeed;
            }
            else{
                MotorB_DutyCycle = MotorB_SlowSpeed;
            }
        /* Motor C */
            deviation[MotorC] = desiredPosition[MotorC] - actualPosition[MotorC];
            absoluteDeviation[MotorC] = abs(deviation[MotorC]);
            /*Direction Control */
            if (deviation[MotorC] >= PID_Offset){
                motor_C_right = 1;
                inPosition[MotorC] = false;
            }
            else if (deviation[MotorC] <= -PID_Offset){
                motor_C_left = 1;
                inPosition[MotorC] = false;
            }
            else{
                MotorC_DutyCycle = 0;
                motor_C_right = 0;
                motor_C_left = 0;
                inPosition[MotorC] = true;
            }
            /*Velocity Control */
            if (absoluteDeviation[MotorC] >= MotorC_SpeedBoundary){
                MotorC_DutyCycle = MotorC_HighSpeed;
            }
            else{
                MotorC_DutyCycle = MotorC_SlowSpeed;
            }   
}